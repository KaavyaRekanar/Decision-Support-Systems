package com.example.accidentuser;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Random;
import java.util.TimeZone;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Paint;
import android.graphics.Paint.FontMetricsInt;
import android.graphics.Point;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.text.Spanned;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.LayoutAnimationController;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;



//import com.actionbarsherlock.app.ActionBar;
//import com.actionbarsherlock.app.SherlockActivity;
//import com.actionbarsherlock.app.SherlockFragmentActivity;
//import com.ongo.odisha.R;
//import com.cx.ongo.db.OnGoDaoImpl;
//import com.cx.ongo.dto.Widgets;
//import com.facebook.Session;
//import com.google.android.gms.ads.AdRequest;
//import com.google.android.gms.ads.AdView;
//import com.google.android.gms.common.api.GoogleApiClient;
//import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
//import com.google.android.gms.common.api.PendingResult;
//import com.google.android.gms.common.api.ResultCallback;
//import com.google.android.gms.location.LocationListener;
//import com.google.android.gms.location.LocationRequest;
//import com.google.android.gms.location.LocationServices;
//import com.google.android.gms.location.LocationSettingsRequest;
//import com.google.android.gms.location.LocationSettingsResult;
//import com.google.android.gms.location.LocationSettingsStatusCodes;

public class Utils {

	public static String NO_NET = "Internet Not Available";
	public static String CHK_NET = "Check your Internet Connection";
	public static String regular_Font = "Regular";
	public static String semiBold_Font = "SemiBold";
	public static String bold_Font = "Bold";
	public static String droidSerif = "droidSerif";
	public static String  arial="arial";
	public static String  arial_bold="arial_bold";
	public static String  roboto="roboto";
	public static String  roboto_bold="roboto_bold";
	private static boolean result;
	public String gPlus = "Google+";
	
//	public static String getGuestMail(SharedPreferences mPreferences) {
//		return mPreferences.getString(OnGoConstants.PREF_GUESTMAILL, "");
//	}
	

//	public static String getGuestUserId(SharedPreferences mPreferences) {
//		return mPreferences.getString(OnGoConstants.PREF_GUEST_USERID, "");
//	}
	
	
	
	
	public static enum weekDays{
		Mon(Calendar.MONDAY),Tue(Calendar.TUESDAY), Wed(Calendar.WEDNESDAY), Thu(Calendar.THURSDAY), Fri(Calendar.FRIDAY), Sat(Calendar.SATURDAY), Sun(Calendar.SUNDAY);
		
		public int name;
		
		weekDays(int name) {
			this.name = name;
		}
	}
	
	public static enum currency{
		INR("20B9"),USD("0024"),AUD("0024"),NZD("0024");
		public String currency;
		private currency(String currency) {
			this.currency = currency; 
		}
	}
	
//	private static GoogleApiClient client = null;
//	private static LocationRequest request = null;
	
	
//	public static void turnGPSOn(final Activity activity, final Editor mPrefEditor, final boolean showDialog){
//		request = new LocationRequest().setNumUpdates(1).setExpirationDuration(30000).setInterval(1000).setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
//		client = new GoogleApiClient.Builder(activity).addApi(LocationServices.API).addConnectionCallbacks(new ConnectionCallbacks() {
//
//			@Override
//			public void onConnectionSuspended(int cause) {
//			}
//
//			@Override
//			public void onConnected(Bundle connectionHint) {
//				try {
//					LocationServices.FusedLocationApi.requestLocationUpdates(client, request, new LocationListener() {
//
//
//						@Override
//						public void onLocationChanged(Location location) {
//							if (location != null) {
//								double latitude = location.getLatitude();
//								double longitude = location.getLongitude();
//								if (latitude != 0.0 && longitude != 0.0 && mPrefEditor != null) {
//									mPrefEditor.putString(OnGoConstants.PREF_LAT, "" + latitude);
//									mPrefEditor.putString(OnGoConstants.PREF_LONG, "" + longitude);
//									mPrefEditor.commit();
//								}
//							}
//						}
//					});
//				} catch (Exception e) {
//				}
//			}
//		}).build();
//
//		if (client != null && !client.isConnected()) {
//			client.connect();
//		}
//
//		LocationSettingsRequest.Builder b =  new LocationSettingsRequest.Builder().addLocationRequest(request);
//		PendingResult<LocationSettingsResult> result = LocationServices.SettingsApi.checkLocationSettings(client, b.build());
//		result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
//
//			@Override
//			public void onResult(LocationSettingsResult result) {
//				switch(result.getStatus().getStatusCode()) {
//				case LocationSettingsStatusCodes.SUCCESS:
//					break;
//				case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
//					if (showDialog) {
//						try {
//							result.getStatus().startResolutionForResult(activity, 1338);
//						} catch (IntentSender.SendIntentException e) {
//							e.printStackTrace();
//						}
//					}
//					break;
//				case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
//					break;
//				}
//			}
//		});
//	}

	public static Spanned getCurrency(String language) {
		String stringText = "";
		try {
			for (currency currencySet : currency.values()) {
				if (currencySet.name().equalsIgnoreCase(language)) {
					int hexValue = Integer.parseInt("" + currencySet.currency, 16);
					stringText += (char)hexValue;
					return Html.fromHtml(stringText);
				}
			}
		} catch (Exception e) {
			return Html.fromHtml(stringText);
		}
		return Html.fromHtml(stringText);
	}
	
	public static enum keys{
		groupName("Group Name");
		
		public String name;
		keys(String name) {
			this.name = name;
		}
	}
	
	
	public static enum shareNames{
		Whatsapp("com.whatsapp"),Gmail("com.google.android.gm"), Skype("com.skype.raider"), Facebook("com.facebook.katana"), Linkedin("com.linkedin.android"), 
		Instagram("com.instagram.android"), Twitter("com.twitter.android"), Hangouts("com.google.android.talk"), 
		Messaging("com.thinkyeah.message"), gPlus("com.google.android.apps.plus"), Pinterest("com.pinterest");

		public String name;
		
		shareNames(String name) {
			this.name = name;
		}
	}
	
	public static enum excludedProps {ItemCode, id, Name, createdById, jobTypeId, createdByFullName, publicURL, ExpiredOn, Quantity, In_Stock, guestUserId, guestUserEmail, 
		Image_Name, Image_URL, Latitude, Longitude, Attachments, Additional_Details, jobComments, Current_Job_Status,Category_Mall, MRP, Insights,
		Current_Job_StatusId, Next_Seq_Nos, CreatedSubJobs, Next_Job_Statuses, offersCount, productsCount, businessType, storeId, CategoryType, SubCategoryType, 
		P3rdCategory, Description, createdOn, jobTypeName, hrsOfOperation, overallRating, totalReviews, ServiceType};
		
	public static void CopyStream(InputStream is, OutputStream os) {
		final int buffer_size = 1024;
		try {
			byte[] bytes = new byte[buffer_size];
			for (;;) {
				int count = is.read(bytes, 0, buffer_size);
				if (count == -1)
					break;
				os.write(bytes, 0, count);
			}
		} catch (Exception ex) {
		}
	}
	
	
//	public static Widgets isWidgetVisible(ArrayList<Widgets> widgets, String string, Context mContext) {
//		if (widgets != null && widgets.size() > 0) {
//			for (int i = 0; i < widgets.size(); i++) {
//				if (widgets.get(i).Name != null && widgets.get(i).Name.equalsIgnoreCase(string)) {
//					if (widgets.get(i).Widget_Type != null && (widgets.get(i).Widget_Type.equalsIgnoreCase("Native") || widgets.get(i).Widget_Type.equalsIgnoreCase("Custom Tab"))) {
//						if (widgets.get(i).Visibility != null && widgets.get(i).Visibility.equalsIgnoreCase("YES")) {
//							return widgets.get(i);
//						}
//					}
//				}
//			}
//		}
//		return null;
//	}
	
//	public static Widgets isWidgetVisible(String string, Context mContext) {
//		OnGoDaoImpl mDaoImpl = new OnGoDaoImpl(mContext);
//		ArrayList<Widgets> widgets = mDaoImpl.getWidgets(Utils.getMallId(mContext));
//		if (widgets != null && widgets.size() > 0) {
//			for (int i = 0; i < widgets.size(); i++) {
//				if (widgets.get(i).Name != null && widgets.get(i).Name.equalsIgnoreCase(string)) {
//					if (widgets.get(i).Widget_Type != null && (widgets.get(i).Widget_Type.equalsIgnoreCase("Native") || widgets.get(i).Widget_Type.equalsIgnoreCase("Custom Tab"))) {
//						if (widgets.get(i).Visibility != null && widgets.get(i).Visibility.equalsIgnoreCase("YES")) {
//							return widgets.get(i);
//						}
//					}
//				}
//			}
//		}
//		return null;
//	}
	
//	public static void loadAdsInFragment(ArrayList<Widgets> mWidgets, Context mContext, View inflatedLayout) {
//		Widgets adsWidget;
//		if (mWidgets != null) {
//			adsWidget = isWidgetVisible("Google Ads", mContext);
//		} else {
//			adsWidget = isWidgetVisible(mWidgets, "Google Ads", mContext);
//		}
//		AdView mAdView;
//		if (inflatedLayout != null) {
//			mAdView = (AdView)inflatedLayout.findViewById(R.id.adView);
//		} else {
//			mAdView = (AdView)((Activity) mContext).findViewById(R.id.adView);
//		}
//		if (mAdView != null) {
//			if (adsWidget != null) {
//				mAdView = (AdView)((Activity) mContext).findViewById(R.id.adView);
//				// Create an ad request. Check logcat output for the hashed device ID to
//				// get test ads on a physical device. e.g.
//				// "Use AdRequest.Builder.addTestDevice("ABCDEF012345") to get test ads on this device."
//				AdRequest adRequest = new AdRequest.Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR).build();
//
//				// Start loading the ad in the background.
//				mAdView.loadAd(adRequest);
//			} else {
//				mAdView.setVisibility(View.GONE);
//			}
//		}
//	}
//
//	public static String getWidgetDisplayName(Widgets widgets) {
//		if(widgets != null) {
//			if (widgets.Display_Name != null && (!widgets.Display_Name.equals(""))) {
//				return widgets.Display_Name;
//			} else {
//				return widgets.Name;
//			}
//		}
//		return "";
//	}
//
//	public static void fbLogout(Context mContext) {
//		Session session = Session.getActiveSession();
//	    if (session != null) {
//
//	        if (!session.isClosed()) {
//	            session.closeAndClearTokenInformation();
//	            //clear your preferences if saved
//	        }
//	    } else {
//	        session = new Session(mContext);
//	        Session.setActiveSession(session);
//	        session.closeAndClearTokenInformation();
//	            //clear your preferences if saved
//
//	    }
//
//	}
	
	public static String changeUTCtimeToLocalFormat(String time) {
		String formattedDate ;
		try {
			SimpleDateFormat df = new SimpleDateFormat("MMM dd, yyyy hh:mm:ss a",Locale.getDefault());
			df.setTimeZone(TimeZone.getTimeZone("UTC"));
			Date date = df.parse(time);
			df.setTimeZone(TimeZone.getDefault());
			formattedDate = df.format(date);
			return formattedDate;
		} catch (ParseException e) {
			e.printStackTrace();
			return time;
		}
	}
	
//	public static void removeLoginPreferences(Editor mPrefEditor) {
//		mPrefEditor.remove(OnGoConstants.PREF_MACID);
//		mPrefEditor.remove(OnGoConstants.PREF_STATE);
//		mPrefEditor.remove(OnGoConstants.PREF_USER_ID);
//		mPrefEditor.remove(OnGoConstants.PREF_COUNTRY);
//		mPrefEditor.remove(OnGoConstants.PREF_COVER_IMAGE);
//		mPrefEditor.remove(OnGoConstants.PREF_PROFILE_IMAGE);
//		mPrefEditor.remove(OnGoConstants.PREF_FIRST_NAME);
//		mPrefEditor.remove(OnGoConstants.PREF_LAST_NAME);
//		mPrefEditor.remove(OnGoConstants.PREF_USER_NAME);
//		mPrefEditor.remove(OnGoConstants.PREF_CITY);
//		mPrefEditor.remove(OnGoConstants.PREF_EMAIL_ID);
//		mPrefEditor.remove(OnGoConstants.PREF_ORGANIZATION);
//		mPrefEditor.remove(OnGoConstants.PREF_ADDRESS);
//		mPrefEditor.remove(OnGoConstants.PREF_MOBILE);
//		mPrefEditor.commit();
//	}
	
	public static boolean checkType(String type) {
		if (type != null && (!type.equals(""))) {
			for (excludedProps propName : excludedProps.values()) {
				if (propName.name().equalsIgnoreCase(type))
					return false;
			}
		}
		if (type.equalsIgnoreCase("YouTube URL"))
			return false;
		return true;
	}
	
	public static String getWeek(int type) {
		for (weekDays propName : weekDays.values()) {
			if (propName.name == (type))
				return propName.name();
		}
		return "";
	}
	
	public static String getShareWidgetName(String packageName) {
		for (shareNames propName : shareNames.values()) {
			if (propName.name.equalsIgnoreCase((packageName)))
				return propName.name();
		}
		return "";
	}
	
	public static String getKeyName(String keyName) {
		for (keys propName : keys.values()) {
			if (propName.name.equalsIgnoreCase((keyName)))
				return propName.name();
		}
		return "";
	}
	
//	public static void setScreenTitle(String screenTitle, Context mContext, String activity, boolean verified) {
//		ActionBar actionBar = null;
//		if (activity.equalsIgnoreCase("SherlockActivity")) {
//			actionBar = ((SherlockActivity) mContext).getSupportActionBar();
//		} else if (activity.equalsIgnoreCase("SherlockFragmentActivity")) {
//			actionBar = ((SherlockFragmentActivity) mContext).getSupportActionBar();
//		} else if (activity.equalsIgnoreCase("SlidingFragmentActivity")) {
//			/*actionBar = ((SlidingFragmentActivity) mContext).getSupportActionBar();*/
//		}
//		TextView textView = new TextView(mContext);
//		textView.setTextColor(Color.BLACK);
//		textView.setPadding(0, 0, 0, 0);
//		textView.setTextSize(20);
//		textView.setGravity(Gravity.CENTER);
//		textView.setSingleLine(true);
//		textView.setEllipsize(TruncateAt.END);
//		if (screenTitle != null) {
//			textView.setText(screenTitle);
//		} else {
//			textView.setText("");
//		}
//		if (verified) {
//			textView.setCompoundDrawablesWithIntrinsicBounds(null, null, mContext.getResources().getDrawable(R.drawable.verifiedcircle), null);
//		} else {
//			textView.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
//		}
//		setFont(textView, semiBold_Font, "TextView");
//
//
//	}
	
	
	public static void setFont(View element, String type, String viewName) {
		Context context = element.getContext();
		if (viewName.equalsIgnoreCase("TextView")) {
			((TextView) element).setTypeface(getFontFromAsset(context, type));
		} else if (viewName.equalsIgnoreCase("EditText")) {
			((EditText) element).setTypeface(getFontFromAsset(context, type));
		}  else if (viewName.equalsIgnoreCase("Button")) {
			((Button) element).setTypeface(getFontFromAsset(context, type));
		} else if (viewName.equalsIgnoreCase("AutoCompleteTextView")) {
			((AutoCompleteTextView) element).setTypeface(getFontFromAsset(context, type));
		} 
		
		if (viewName.equalsIgnoreCase("TextView") &&( type.equals(Utils.arial_bold) || type.equals(Utils.roboto_bold))) {
			((TextView) element).setTypeface(getFontFromAsset(context, type),getFontFromAsset(context, type).BOLD);
			
		}
		
		
	}

	public static Typeface getFontFromAsset(Context context, String type) {
		Typeface typeface = null;
		if (type.equals(Utils.bold_Font)) {
			typeface = Typeface.createFromAsset(context.getAssets(), "bold.otf");
		} else if (type.equals(Utils.semiBold_Font)) {
			typeface = Typeface.createFromAsset(context.getAssets(), "semibold.otf");
		} else if (type.equals(Utils.regular_Font)) {
			typeface = Typeface.createFromAsset(context.getAssets(), "regular.otf");
		} else if (type.equals(Utils.droidSerif)) {
			typeface = Typeface.createFromAsset(context.getAssets(), "DroidSerif.ttf");
		}else if (type.equals(Utils.arial)) {
			typeface = Typeface.createFromAsset(context.getAssets(), "arial.ttf");
		}else if (type.equals(Utils.arial_bold)) {
			typeface = Typeface.createFromAsset(context.getAssets(), "arial.ttf");
		}else if (type.equals(Utils.roboto)) {
			typeface = Typeface.createFromAsset(context.getAssets(), "Roboto-Regular.ttf");
		}else if (type.equals(Utils.roboto_bold)) {
			typeface = Typeface.createFromAsset(context.getAssets(), "Roboto-Regular.ttf");
		}
		return typeface;
	}
	
	public static int tabsHeight(Context cont){
		int alt;
		int dx, dy;
		DisplayMetrics metrics = cont.getResources().getDisplayMetrics();
		
		dx = metrics.widthPixels;
		dy = metrics.heightPixels;
		if (dx < dy)
			alt = dy/16;
		else
			alt = dy/12;
		
		return alt;
	}
	
	public static int tabsWidth(Context cont){
		int alt;
		int dx;
		DisplayMetrics metrics = cont.getResources().getDisplayMetrics();
		
		dx = metrics.widthPixels;
		alt = dx/5;
		
		return alt;
	}
	
//	public static String getMacId(Context mContext) {
//		WifiManager manager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
//		WifiInfo wifiInfo = manager.getConnectionInfo();
//		String MacAddress = wifiInfo.getMacAddress();
//		return MacAddress;
//	}
	

	

	
	/**
	 * @param mContext
	 * @return string from Strings File
	 */
	public static String getString(Context mContext, int id) {
		return mContext.getResources().getString(id);
	}

	public static boolean isNetworkAvailable(Context ctx) {
		ConnectivityManager mConnectivityManager = (ConnectivityManager) ctx
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (mConnectivityManager
				.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED
				|| mConnectivityManager.getNetworkInfo(
						ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
			return true;
		} else
			return false;
	}

	public static void toast(String msg, Context ctx) {
		Toast toast = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT);
		try {
			LinearLayout toastLayout = (LinearLayout) toast.getView();
			TextView toastTV = (TextView) toastLayout.getChildAt(0);
			toastTV.setTextSize(16);
			setFont(toastTV, droidSerif, "TextView");
			toast.show();			
		} catch (Exception e) {
		} finally {
			toast.show();
		}
	}
	
	public static String getDocNo(Context ctx){
		TelephonyManager telephonyManager = (TelephonyManager)ctx.getSystemService(Context.TELEPHONY_SERVICE);
		Random rnd = new Random();
		String doc_no=telephonyManager.getDeviceId().toString().trim()+String.valueOf((100000 + rnd.nextInt(999999))).trim();
		return doc_no;
	}
	
	/**
	 * @param mContext
	 * To hide soft key board
	 */
	public static void hideSoftKeyboard(Context mContext) {
		try {
			InputMethodManager inputMethodManager = (InputMethodManager)  mContext.getSystemService(Activity.INPUT_METHOD_SERVICE);
			if (inputMethodManager.isAcceptingText()) {
				inputMethodManager.hideSoftInputFromWindow(((Activity) mContext).getCurrentFocus().getWindowToken(), 0);
			} else {}
		} catch (Exception e) {}
	}

	public static float SetTextSize(String text, Context mContext) {
		Paint paint = new Paint();
		float textWidth = paint.measureText(text);
		float textSize = (int) (((get_Width(mContext) * 0.4) / textWidth) * paint
				.getTextSize());
		paint.setTextSize(textSize);

		textWidth = paint.measureText(text);
		textSize = (int) (((get_Width(mContext) * 0.4) / textWidth) * paint
				.getTextSize());

		// Re-measure with font size near our desired result
		paint.setTextSize(textSize);
		// Check height constraints
		FontMetricsInt metrics = paint.getFontMetricsInt();
		float textHeight = metrics.descent - metrics.ascent;
		if (textHeight > (get_Height(mContext) * 0.45)) {
			textSize = (int) (textSize * ((get_Height(mContext) * 0.45) / textHeight));
			paint.setTextSize(textSize);
		}
		return textSize;
	}

	@SuppressLint("NewApi")
	public static int get_Width(Context mContext) {
		int screenWidth;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
			Point size = new Point();
			((Activity) mContext).getWindowManager().getDefaultDisplay()
					.getSize(size);
			screenWidth = size.x;
		} else {
			screenWidth = mContext.getResources().getDisplayMetrics().widthPixels;
		}
		return screenWidth;
	}

	@SuppressLint("NewApi")
	public static int get_Height(Context mContext) {
		int screenHeight;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
			Point size = new Point();
			((Activity) mContext).getWindowManager().getDefaultDisplay()
					.getSize(size);
			screenHeight = size.y;
		} else {
			screenHeight = mContext.getResources().getDisplayMetrics().heightPixels;
		}
		return screenHeight;
	}

	public static int get_Dpi(Context mContext) {
		return mContext.getResources().getDisplayMetrics().densityDpi;
	}

	@SuppressLint("NewApi")
	public static void dialog(final Context mContext, String title, String mesg) {
		Builder alert = new Builder(mContext);
		alert.setTitle(title);
		alert.setMessage(mesg);
		//alert.setIcon(R.drawable.splash_image);
		alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.dismiss();
			}
		});
		AlertDialog a = ((Builder) alert).create();
		a.show();
	}




	/**
	 * @param mContext
	 * @param title
	 * @param mesg
	 * @return boolean
	 */
	public static boolean decisionDialog(final Context mContext, String title, String mesg) {
		 result=false;
		Builder alert = new Builder(mContext);
		alert.setTitle(title);
		alert.setMessage(mesg);
		//alert.setIcon(R.drawable.splash_image);
		alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				result=true;
				dialog.dismiss();
			}
		});
		alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				result=false;
				dialog.dismiss();
			}
		});

		AlertDialog a = ((Builder) alert).create();
		a.show();

		return  result;
	}

	@SuppressLint("NewApi")
	public static void animate(ExpandableListView expandableListView, ListView listView, GridView gridView, SearchView linearLayout) {
		AnimationSet set = new AnimationSet(true);
		Animation animation = new AlphaAnimation(0.0f, 1.0f);
		animation.setDuration(500);
		set.addAnimation(animation);

		animation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f,
				Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF,
				-1.0f, Animation.RELATIVE_TO_SELF, 0.0f);
		animation.setDuration(500);
		set.addAnimation(animation);

		LayoutAnimationController controller = new LayoutAnimationController(
				set, 0.5f);
		if (listView != null) {
			listView.setLayoutAnimation(controller);
		} else if (gridView != null) {
			gridView.setLayoutAnimation(controller);
		} else if (expandableListView != null) {
			expandableListView.setLayoutAnimation(controller);
		} else {
			linearLayout.setLayoutAnimation(controller);
		}
	}

	@SuppressLint("NewApi")
	public static ArrayList<String> convertStringToArray(String str) {
		ArrayList<String> arrayList = new ArrayList<String>();
		if (str.contains(",")) {
			String[] arr = str.split(",");
			for (int i = 0; i < arr.length; i++) {
				arrayList.add(arr[i]);
			}
			return arrayList;
		} else {
			if (!(str.equals(""))) {
				arrayList.add(str);
			}
			return arrayList;
		}
	}
	
	 
	public static String convertArrayToString(ArrayList<String> array) {
		String str = "";
		if (array != null) {
			for (int i = 0; i < array.size(); i++) {
				str = str + array.get(i);
				// Do not append comma at the end of last element
				if (i < array.size() - 1) {
					str = str + ",";
				}
			}
		}
		return str;
	}

	public static ArrayList<String> remove_Duplicates(
			ArrayList<String> with_Duplicates) {
		ArrayList<String> no_DuplicatesList = new ArrayList<String>();
		HashSet<String> hashSet = null;
		ArrayList<String> arrayList = null;
		if (with_Duplicates != null) {
			hashSet = new HashSet<String>(with_Duplicates);
		}
		if (hashSet != null) {
			arrayList = new ArrayList<String>(hashSet);
		}
		if (arrayList != null) {
			for (int i = 0; i < arrayList.size(); i++) {
				if (arrayList.get(i) != null && (!arrayList.get(i).equals(""))) {
					no_DuplicatesList.add(arrayList.get(i));
				}
			}
		}
		return no_DuplicatesList;
	}
	@SuppressLint("NewApi")
	public static boolean isNotNull(String s) {
		if (!s.isEmpty() && s != null)
			return true;
		else
			return false;

	}

	/* Android Version Codes */

	// Platform Version API Level
	// Android 4.2 17
	// Android 4.1 16
	// Android 4.0.3 15
	// Android 4.0 14
	// Android 3.2 13
	// Android 3.1 12
	// Android 3.0 11
	// Android 2.3.3 10
	// Android 2.3 9
	// Android 2.2 8
	// Android 2.1 7
	// Android 2.0.1 6
	// Android 2.0 5
	// Android 1.6 4
	// Android 1.5 3
	// Android 1.1 2
	// Android 1.0 1

	public static boolean appInstalledOrNot(Context ctx, String uri) {
		PackageManager pm = ctx.getPackageManager();
		boolean app_installed = false;
		try {
			pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
			app_installed = true;
		} catch (PackageManager.NameNotFoundException e) {
			app_installed = false;
		}
		return app_installed;
	}

	public static void gotoMarket(String string, Context mContext) {
		Uri uri = Uri.parse("market://search?q=pname:" + string);
		Intent intent = new Intent(Intent.ACTION_VIEW, uri);
		try {
			mContext.startActivity(intent);
		} catch (ActivityNotFoundException e) {
		}
	}

	public static String removeLeading_and_TrailingSpaces(String string) {
		string = string.replaceAll("^\\s+|\\s+$", "");
		return string;
	}
	
	
	/**
	 * Webview UTF - 8 
	 **/
	
	@SuppressLint({ "SetJavaScriptEnabled", "NewApi" })
	public static void webViewUTF(WebView webview, String htmlCode, int fontSize) {
		if(webview != null && htmlCode != null && !htmlCode.equalsIgnoreCase("")) {
			WebSettings webSettings = webview.getSettings();
			if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
				webSettings.setSupportZoom(false);  
				webSettings.setDisplayZoomControls(false);
				webSettings.setBuiltInZoomControls(false);
			}
			webSettings.setJavaScriptEnabled(true);
			webSettings.setAllowFileAccess(true);
			webSettings.setDefaultTextEncodingName("UTF-8");
			webSettings.setLoadsImagesAutomatically(true);
			webview.setInitialScale(100);
			
			try {
				String content = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"+
						"<html><head>"+
						"<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\" />" 
						+ "<style> "
						+ "@font-face { font-family: DroidSerifFont; src: url(\"file:///android_asset/regular.otf\") }"
						+ "body { color:black;" + " font-family:DroidSerifFont;font-size:" + fontSize + ";} "
						+ "p { color:black;" + " font-family:DroidSerifFont;font-size:" + fontSize + ";} "
						+ "table { color:black;" + " font-family:DroidSerifFont;font-size:" + fontSize + ";} "
						+ " </style>" 
						+ "</head><body> <div style='font-family:DroidSerifFont;'font-size:" + fontSize + ";>";
				content += htmlCode + "</div></body></html>";
				Log.i("htmlCode", " content " + content);
				webview.loadData(content, "text/html; charset=utf-8", "UTF-8");			
			} catch (Exception e) {
				try {
					webview.loadUrl(htmlCode);
				} catch (Exception e2) {}
			}
		}
	}
	
	/**
	 * For Audio Utils
	 * **/
	
	/**
	 * Function to convert milliseconds time to
	 * Timer Format
	 * Hours:Minutes:Seconds
	 * */
	public String milliSecondsToTimer(long milliseconds){
		String finalTimerString = "";
		String secondsString = "";
		
		// Convert total duration into time
		   int hours = (int)( milliseconds / (1000*60*60));
		   int minutes = (int)(milliseconds % (1000*60*60)) / (1000*60);
		   int seconds = (int) ((milliseconds % (1000*60*60)) % (1000*60) / 1000);
		   // Add hours if there
		   if(hours > 0){
			   finalTimerString = hours + ":";
		   }
		   
		   // Prepending 0 to seconds if it is one digit
		   if(seconds < 10){ 
			   secondsString = "0" + seconds;
		   }else{
			   secondsString = "" + seconds;}
		   
		   finalTimerString = finalTimerString + minutes + ":" + secondsString;
		
		// return timer string
		return finalTimerString;
	}
	
	/**
	 * Function to get Progress percentage
	 * @param currentDuration
	 * @param totalDuration
	 * */
	public int getProgressPercentage(long currentDuration, long totalDuration){
		Double percentage = (double) 0;
		
		long currentSeconds = (int) (currentDuration / 1000);
		long totalSeconds = (int) (totalDuration / 1000);
		
		// calculating percentage
		percentage =(((double)currentSeconds)/totalSeconds)*100;
		
		// return percentage
		return percentage.intValue();
	}

	/**
	 * Function to change progress to timer
	 * @param progress - 
	 * @param totalDuration
	 * returns current duration in milliseconds
	 * */
	public int progressToTimer(int progress, int totalDuration) {
		int currentDuration = 0;
		totalDuration = (int) (totalDuration / 1000);
		currentDuration = (int) ((((double)progress) / 100) * totalDuration);
		
		// return current duration in milliseconds
		return currentDuration * 1000;
	}

	public static String getCurrentTime(){
		Calendar c= Calendar.getInstance();
		int mHour=c.get(Calendar.HOUR_OF_DAY);
		int mMinute=c.get(Calendar.MINUTE);
		int mSec=c.get(Calendar.SECOND);
		
		
		String currentTime=mHour+":"+mMinute+":"+mSec;
		
		return currentTime;
	}
	
}