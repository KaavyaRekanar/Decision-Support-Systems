package com.example.accidentuser;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity  {

	Button btnEmergency,btnFireEmergency,btnMedicalEmergency;
	EditText etNum;
	Context mContext;

	GPSTracker gps;

	protected LocationListener locationListner;
	protected LocationManager locationManager;
	private String lat = "";
	private String lng = "";
	private String num = "+46767702620";// "+46767702620";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mContext = this;
		
		btnEmergency = (Button) findViewById(R.id.btnEmergency);
		btnFireEmergency = (Button) findViewById(R.id.btnFireEmergency);
		btnMedicalEmergency = (Button) findViewById(R.id.btnMedicalEmergency);
		
		
		etNum = (EditText) findViewById(R.id.etMobileNo);


		btnEmergency.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				sendSMS("Crime");
			}
		});
		
		btnFireEmergency.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				sendSMS("Fire");
			}
		});
		
		btnMedicalEmergency.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				sendSMS("Medical");
			}
		});
		

		gps = new GPSTracker(mContext);
	}

	protected void sendSMS(String type) {
		try {
			if (gps.canGetLocation) {

				lat = String.valueOf(gps.getLatitude());
				lng = String.valueOf(gps.getLongitude());

				SmsManager smsMan = SmsManager.getDefault();
				JSONObject jObj;
				jObj = new JSONObject();
				try {
					jObj.put("Lat", lat);
					jObj.put("Lng", lng);
					jObj.put("Emergency Request", type);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Intent sendIntent = new Intent(Intent.ACTION_VIEW);
				sendIntent.putExtra("sms_body", jObj.toString());
				sendIntent.putExtra("address", num); 
				sendIntent.setType("vnd.android-dir/mms-sms");
				startActivity(sendIntent);
				
				
			//	smsMan.sendTextMessage(num, null, jObj.toString(), null, null);
			//	Utils.toast("SMS Sent", mContext);
			} else
				Utils.toast("Please turn on GPS", mContext);
		} catch (Exception e) {
			Toast.makeText(getApplicationContext(),
					"SMS failed, please try again.", Toast.LENGTH_LONG).show();
			e.printStackTrace();
		}

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}	
}
