package com.project.accidentadmin;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by tlc on 23/4/15.
 */
public class SharedPrefUtility {

    Context c;
    SharedPreferences sharedPref;
    private final String SHARED_LIB = "DETAILS";
    private final String IP = "IP";

    SharedPrefUtility(Context context) {
        c = context;

        sharedPref = c.getSharedPreferences(SHARED_LIB, Activity.MODE_PRIVATE);
    }


    public String getTechId(){

        return sharedPref.getString("TechId","");
    }

    public void setTechId(String techId){

        SharedPreferences.Editor edit=sharedPref.edit();
        edit.putString("TechId",techId);
        edit.commit();
    }

    public boolean setUrl(String ip) throws Exception {
        try {
            SharedPreferences.Editor edit = sharedPref.edit();
            //format - http://17.0.0.1:8080/
            
            edit.putString(IP, ip);
            edit.commit();
            return true;


        }catch (Exception e){
            e.printStackTrace();
            return false;
        }


    }

    public String getUrl(){
        return sharedPref.getString(IP,"");//+Constants.getWebServiceURl();
    }

}
