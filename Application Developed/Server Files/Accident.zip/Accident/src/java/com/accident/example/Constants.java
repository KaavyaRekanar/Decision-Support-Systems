/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.accident.example;

/**
 *
 * @author tlc
 */
public class Constants {
    public static String dbClass = "com.mysql.jdbc.Driver";
    private static String dbName= "accident";
    public static String dbUrl = "jdbc:mysql://localhost:3306/"+dbName;
    public static String dbUser = "root";
    public static String dbPwd = "password";
}