/** Automatically generated file. DO NOT MODIFY */
package com.project.accidentadmin;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}