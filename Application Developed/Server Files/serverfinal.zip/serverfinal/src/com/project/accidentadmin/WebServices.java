package com.project.accidentadmin;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

public class WebServices extends Activity {

	/**
	 * Method that performs RESTful webservice invocations
	 * 
	 * @param params
	 */

	Context context;
	List<String> data;
	SharedPrefUtility sharedPref;

	WebServices(Context c) {
		this.context = c;
		sharedPref = new SharedPrefUtility(c);
		data = new ArrayList<String>();
	}

	public List<String> invokeWebService(RequestParams params,
			final String tag, final WSResponnse dataResponse,
			final String... tagValues) {
		// Show Progress Dialog

		// Make RESTful webservice call using AsyncHttpClient object
		AsyncHttpClient client = new AsyncHttpClient();

		Log.i("test", getUrl(tag));

	//	Toast.makeText(context, getUrl(tag)+" is url", Toast.LENGTH_LONG).show();

		client.get(getUrl(tag), params, new AsyncHttpResponseHandler() {
			// When the response returned by REST has Http response code
			// '200'
			@Override
			public void onSuccess(String response) {
				// Hide Progress Dialog
					dataResponse.onResponse(true, response);
			}

			// When the response returned by REST has Http response code
			// other than '200'
			@Override
			public void onFailure(int statusCode, Throwable error,
					String content) {
				// Hide Progress Dialog

				// When Http response code is '404'
				if (statusCode == 404) {
					Toast.makeText(context,
							"Requested resourc" + "+e not found",
							Toast.LENGTH_LONG).show();
				}
				// When Http response code is '500'
				else if (statusCode == 500) {
					Toast.makeText(context,
							"Something went wrong at server end",
							Toast.LENGTH_LONG).show();
				}
				// When Http response code other than 404, 500
				else {
					Toast.makeText(
							context,
							"Unexpected Error occcured! [Most common Error: Device might not be connected to Internet or remote server is not up and running]",
							Toast.LENGTH_LONG).show();
				}
				dataResponse.onResponse(false, "");

			}
		});

		return data;
	}

	public List<String> parseJSON(String response, String tag,
			String... tagValues) throws JSONException {
		List<String> values = new ArrayList<String>();
		// JSON Object
		
		return values;
	}

	public String getUrl(String tag) {
		String url = null;
		String urlIp = "http://"+sharedPref.getUrl()+"/";
		if (tag.equalsIgnoreCase("Send")) {
			url = urlIp
					+ "Accident/accident/doinsert_records";
		}
		return url;
	}
}
