package com.project.accidentadmin;

import org.json.JSONObject;

public interface WSResponnse {
    public void onResponse(boolean success, String response);
}
