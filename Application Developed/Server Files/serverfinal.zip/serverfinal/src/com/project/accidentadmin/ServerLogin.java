package com.project.accidentadmin;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ServerLogin extends Activity {

	EditText et_IPUpdate;
	Button btnUpdate;

	SharedPrefUtility sharedPref;
	String updateIP;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_server_login);
		et_IPUpdate = (EditText) findViewById(R.id.et_ServerIP);
		sharedPref = new SharedPrefUtility(getApplicationContext());
		btnUpdate = (Button) findViewById(R.id.btn_serverIPUpdate);

		btnUpdate.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				sharedPref = new SharedPrefUtility(getApplicationContext());
				try {
					sharedPref.setUrl(et_IPUpdate.getText().toString());
					
					Toast.makeText(getApplicationContext(),"Data Saved", Toast.LENGTH_LONG).show();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
	}

}
